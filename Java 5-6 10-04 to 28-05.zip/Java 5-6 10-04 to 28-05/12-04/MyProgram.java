class FirstClass {
	public static void main(String[] args) {
		System.out.println("This is First class");
	}
}


class SecondClass {
	public static void main2(String[] args) {
		System.out.println("This is Second class");
	}
}